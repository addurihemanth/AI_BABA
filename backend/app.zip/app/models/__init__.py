"""
AI_BABA ORM Model Registry

Import every ORM model here so SQLAlchemy registers them
with Base.metadata.
"""

# IAM
from app.modules.iam.models.user import User
from app.modules.iam.models.role import Role
from app.modules.iam.models.permission import Permission
from app.modules.iam.models.user_role import UserRole
from app.modules.iam.models.role_permission import RolePermission

# Audit
from app.modules.audit.models.audit_log import AuditLog

__all__ = [
    "User",
    "Role",
    "Permission",
    "UserRole",
    "RolePermission",
    "AuditLog",
]